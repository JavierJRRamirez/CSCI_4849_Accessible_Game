System requirements: pygame and python 3.6 (or later) need to be installed to run the program.

Instructions: To run the program type "python DodgeTheBall.py" in the command line or select the executable file. The 'data' folder with all of the sprites must be in the same directory as the code file.
